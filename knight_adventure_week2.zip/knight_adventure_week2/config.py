import random
import pygame
from math import sin
from pygame import Vector2 as vector
#sizes
screen_width=1280
screen_height=720
FPS=60
tile_size=64
health_bar_width=200
energy_bar_width=140
item_box_size=80
bar_height=20
ui_font_size=36
map_backgrounds={i:pygame.image.load("map/map{}.png".format(i)) for i in [1]}
#animations_speed
animation_speed=0.15
ui_font="font/Silver.ttf"
hitbox_offset_y={"invisible":0,"object":40,"player":-26,"enemy":-26}
#color
water_color="71ddee"
ui_bg_color="#222222"
ui_border_color="#111111"
text_color="#EEEEEE"
health_color="red"
energy_color="blue"
ui_border_color_active="gold"
text_color_selected="#111111"
bar_color="#EEEEEE"
bar_color_selected="#111111"
upgrade_color_selected="#EEEEEE"
magic_data={
    "flame":{"strengh":5, "cost":20, "image_path":"image/magic/flame.png"},
    "heal":{"strengh":20, "cost":10, "image_path":"image/magic/heal.png"}
}
flame=[pygame.transform.scale(pygame.image.load("image/animation_frames/flame/{}.png".format(j)), (tile_size*6,tile_size*2))for j in range(1,6)]
entity_data={"player":{"health":150, "energy":60, "attack":30, "magic":5, "speed":5, "attack_cooldown":400,"switch_magic_cooldown":250,"invulnerable_duration":666},
            "enemy/red_goblin":{'health': 100,'attack':20,'attack_type': 'claw', 'attack_sound':'', 'speed': 3, 'resistance': 2, 'attack_radius': 80, 'notice_radius': 700, "attack_cooldown":1000},
            "enemy/black_goblin":{'health': 200,'attack':10,'attack_type': 'x_slash', 'attack_sound':'', 'speed': 3, 'resistance': 2, 'attack_radius': 80, 'notice_radius': 700,"attack_cooldown":1000},
             "enemy/red_cyclop":{'health': 200,'attack':40,'attack_type': 'x_slash', 'attack_sound':'', 'speed': 3, 'resistance': 5, 'attack_radius':80, 'notice_radius': 700,"attack_cooldown":1500},
             "enemy/green_cyclop":{'health': 400,'attack':20,'attack_type': 'x_slash', 'attack_sound':'', 'speed': 3, 'resistance': 5, 'attack_radius':80, 'notice_radius': 700,"attack_cooldown":1500},
             "boss/blue_tengu":{'health': 600,'attack':60,'attack_type': 'x_slash', 'attack_sound':'', 'speed': 3, 'resistance': 5, 'attack_radius':80, 'notice_radius': 600,"attack_cooldown":1736, "hit_cooldown":836,"damage_frames":{"start":5,"end":7}},
             "boss/red_samurai":{'health': 600,'attack':60,'attack_type': 'x_slash', 'attack_sound':'', 'speed': 3, 'resistance': 5, 'attack_radius':80, 'notice_radius': 600,"attack_cooldown":868, "hit_cooldown":836,"damage_frames":{"start":4,"end":6}}}
#PLAYER ANIMATION
player_animations = {i: [] for i in ["up", "down", "left", "right",
                                   "up_idle", "down_idle", "left_idle", "right_idle",
                                   "up_attack", "down_attack", "left_attack", "right_attack"]}
for i in ["down", "left", "right", "up"]:
    player_animations[i] = [pygame.transform.scale(pygame.image.load("image/player/walk/{}/{}.png".format(i, j)), (tile_size, tile_size))for j in range(1, 5)]
    player_animations[i + "_idle"] = [pygame.transform.scale(pygame.image.load("image/player/idle/{}.png".format(i)), (tile_size, tile_size))]
    player_animations[i + "_attack"] = [pygame.transform.scale(pygame.image.load("image/player/attack/{}.png".format(i)), (tile_size, tile_size))]
player_animations["dead"] = [pygame.transform.scale(pygame.image.load("image/player/dead/dead.png"), (tile_size, tile_size))]
#ENEMY_ANIMATION
black_goblin_animations = {i: [] for i in ["move", "idle", "attack"]}
red_goblin_animations = {i: [] for i in ["move", "idle", "attack"]}
red_cyclop_animations={i: [] for i in ["move", "idle", "attack"]}
green_cyclop_animations={i: [] for i in ["move", "idle", "attack"]}
black_goblin_animations["move"] = [pygame.transform.scale(pygame.image.load("image/{}/row-{}-column-1.png".format("enemy/black_goblin", i)),(tile_size, tile_size)) for i in range(1, 5)]
black_goblin_animations["idle"] = [pygame.transform.scale(pygame.image.load("image/{}/row-{}-column-1.png".format("enemy/black_goblin", i)),(tile_size, tile_size)) for i in [1, 2, 4]]
black_goblin_animations["attack"] = [pygame.transform.scale(pygame.image.load("image/{}/row-{}-column-1.png".format("enemy/black_goblin", i)),(tile_size, tile_size)) for i in [1, 2]]

red_goblin_animations["move"] = [pygame.transform.scale(pygame.image.load("image/{}/row-{}-column-1.png".format("enemy/red_goblin", i)),(tile_size, tile_size)) for i in range(1, 5)]
red_goblin_animations["idle"] = [pygame.transform.scale(pygame.image.load("image/{}/row-{}-column-1.png".format("enemy/red_goblin", i)),(tile_size, tile_size)) for i in [1, 2, 4]]
red_goblin_animations["attack"] = [pygame.transform.scale(pygame.image.load("image/{}/row-{}-column-1.png".format("enemy/red_goblin", i)),(tile_size, tile_size)) for i in [1, 2]]

red_cyclop_animations["move"] = [pygame.transform.scale(pygame.image.load("image/{}/move/row-1-column-{}.png".format("enemy/red_cyclop", i)),(tile_size, tile_size)) for i in range(1, 7)]
red_cyclop_animations["idle"] = [pygame.transform.scale(pygame.image.load("image/{}/idle/row-1-column-{}.png".format("enemy/red_cyclop", i)),(tile_size, tile_size)) for i in range(1,6)]
red_cyclop_animations["attack"] = [pygame.transform.scale(pygame.image.load("image/{}/attack/row-1-column-{}.png".format("enemy/red_cyclop", i)),(tile_size, tile_size)) for i in [2,3]]

green_cyclop_animations["move"] = [pygame.transform.scale(pygame.image.load("image/{}/move/row-1-column-{}.png".format("enemy/green_cyclop", i)),(tile_size, tile_size)) for i in range(1, 7)]
green_cyclop_animations["idle"] = [pygame.transform.scale(pygame.image.load("image/{}/idle/row-1-column-{}.png".format("enemy/green_cyclop", i)),(tile_size, tile_size)) for i in range(1,6)]
green_cyclop_animations["attack"] = [pygame.transform.scale(pygame.image.load("image/{}/attack/row-1-column-{}.png".format("enemy/green_cyclop", i)),(tile_size, tile_size)) for i in [2,3]]

blue_tengu_animations={i:[] for i in ["attack_left","attack_right","hit","dead","idle","move"]}
red_samurai_animations={i:[] for i in ["attack_left","attack_right","hit","dead","idle","move"]}
blue_tengu_animations["move"]=[pygame.transform.scale(pygame.image.load("image/boss/blue_tengu/move/row-1-column-{}.png".format(i)),(tile_size*2.5,tile_size*2.5))for i in range(1,11)]
blue_tengu_animations["attack_left"]=[pygame.transform.scale(pygame.image.load("image/boss/blue_tengu/attack/row-1-column-{}.png".format(i)),(tile_size*4,tile_size*4)if i in range(5,13) else (tile_size*3,tile_size*3))for i in range(1,16)]
blue_tengu_animations["attack_right"]=[pygame.transform.scale(pygame.image.load("image/boss/blue_tengu/attack/row-1-column-{}.png".format(i)),(tile_size*4,tile_size*4)if i in range(5,13) else (tile_size*3,tile_size*3))for i in range(1,16)]
blue_tengu_animations["hit"]=[pygame.transform.scale(pygame.image.load("image/boss/blue_tengu/hit/row-1-column-{}.png".format(i)),(tile_size*2.5,tile_size*2.5))for i in range(1,9)]
blue_tengu_animations["idle"]=[pygame.transform.scale(pygame.image.load("image/boss/blue_tengu/idle/row-1-column-{}.png".format(i)),(tile_size*2.5,tile_size*2.5))for i in range(1,7)]
blue_tengu_animations["dead"]=[pygame.transform.scale(pygame.image.load("image/boss/blue_tengu/dead/row-1-column-{}.png".format(i)),(tile_size*2.5,tile_size*2.5))for i in range(11,0,-1)]

red_samurai_animations["move"]=[pygame.transform.scale(pygame.image.load("image/boss/red_samurai/move/row-1-column-{}.png".format(i)),(tile_size*2.5,tile_size*2.5))for i in range(1,7)]
red_samurai_animations["attack_left"]=[pygame.transform.scale(pygame.image.load("image/boss/red_samurai/attack_left/{}.png".format(i)),(tile_size*3,tile_size*3) if i in [2,3] else(tile_size*2.5,tile_size*2.5))for i in range(1,8)]
red_samurai_animations["attack_right"]=[pygame.transform.scale(pygame.image.load("image/boss/red_samurai/attack_right/{}.png".format(i)),(tile_size*3,tile_size*3) if i in [2,3] else(tile_size*2.5,tile_size*2.5))for i in range(1,8)]
red_samurai_animations["hit"]=[pygame.transform.scale(pygame.image.load("image/boss/red_samurai/hit/row-1-column-{}.png".format(i)),(tile_size*2.5,tile_size*2.5))for i in range(1,5)]
red_samurai_animations["idle"]=[pygame.transform.scale(pygame.image.load("image/boss/red_samurai/idle/row-1-column-{}.png".format(i)),(tile_size*2.5,tile_size*2.5))for i in range(1,7)]
red_samurai_animations["dead"]=[pygame.transform.scale(pygame.image.load("image/boss/red_samurai/dead/row-1-column-2.png"),(tile_size*2.5,tile_size*2.5))]*11

entity_animations={"player":player_animations,"enemy/black_goblin":black_goblin_animations,"enemy/red_goblin":red_goblin_animations,"enemy/red_cyclop":red_cyclop_animations,"enemy/green_cyclop":green_cyclop_animations,"boss/blue_tengu":blue_tengu_animations,"boss/red_samurai":red_samurai_animations}
animation_frames=({i:[pygame.transform.scale(pygame.image.load("image/animation_frames/{}/row-1-column-{}.png".format(i,j)), (tile_size,tile_size))for j in range(1,5)] for i in ["claw","x_slash"]} |
                {i:[pygame.transform.scale(pygame.image.load("image/animation_frames/{}/row-1-column-{}.png".format(i,j)), (tile_size+36,tile_size+36))for j in range(1,6)] for i in ["heal"]} |
                {"flameright":flame} |
                {"flamedown":[pygame.transform.rotate(i,270)for i in flame]} |
                {"flameleft":[pygame.transform.rotate(i,180)for i in flame]} |
                {"flameup":[pygame.transform.rotate(i,90)for i in flame]} |
                {"player_spawn":[pygame.transform.scale(pygame.image.load("image/animation_frames/player_spawn/{}.png".format(i)),(tile_size*1.5,tile_size*1.5)) for i in range(1,5)]} |
                {"enemy_spawn":[pygame.transform.scale(pygame.image.load("image/animation_frames/enemy_spawn/{}.png".format(i)),(tile_size*1.5,tile_size*1.5)) for i in range(1,5)]})
#levels information
initial_position={1:(422, 2973)}
enemy_wave_info={1:[{"list":"enemy/black_goblin "*4,"domain":pygame.Rect(500,2707,550,200)},{"list":"enemy/red_goblin "*4,"domain":pygame.Rect(1120,2387,500,300)},{"list":"enemy/red_goblin "*3+"enemy/black_goblin "*3,"domain":pygame.Rect(1824,1555,450,200)},{"list":"enemy/red_goblin "*3+"enemy/black_goblin "*3,"domain":pygame.Rect(928,541,700,370)}]}
boss_info={1:[{"type":"boss/blue_tengu","pos":(1945,233)}]}