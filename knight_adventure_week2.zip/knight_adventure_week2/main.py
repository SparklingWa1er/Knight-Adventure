import pygame, sys
from config import *
from level import *
class Game:
    def __init__(self):
        pygame.init()
        self.screen=pygame.display.set_mode((screen_width,screen_height))
        self.clock=pygame.time.Clock()
        self.level=Level()
        pygame.display.set_caption("Knight Adventure")
    """    def create_menu(self):
        def draw_menu():
            self.screen.fill(BLACK)
            for i, option in enumerate(options):
                color = GREEN if i == selected_option else WHITE
                text = font.render(option, True, color)
                rect = text.get_rect(center=(400, 300 + i * 40))
                self.screen.blit(text, rect)
            pygame.display.flip()

        def get_option_index(mouse_pos):
            for i, option in enumerate(options):
                text = font.render(option, True, WHITE)
                rect = text.get_rect(center=(400, 300 + i * 40))
                if rect.collidepoint(mouse_pos):
                    return i
            return None

        # Main loop
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        selected_option = (selected_option - 1) % len(options)
                    elif event.key == pygame.K_DOWN:
                        selected_option = (selected_option + 1) % len(options)
                    elif event.key == pygame.K_RETURN:
                        if options[selected_option] == "Start Game":
                            print("Starting game...")
                        elif options[selected_option] == "Options":
                            print("Options selected...")
                        elif options[selected_option] == "Quit":
                            running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = event.pos
                    index = get_option_index(mouse_pos)
                    if index is not None:
                        selected_option = index
                        if options[selected_option] == "Start Game":
                            print("Starting game...")
                        elif options[selected_option] == "Options":
                            print("Options selected...")
                        elif options[selected_option] == "Quit":
                            running = False

            draw_menu()"""
    def run(self):
        while(True):
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            self.screen.fill((164, 212, 17))
            self.level.run()
            pygame.display.update()
            self.clock.tick(FPS)
if  __name__=="__main__":
    game=Game()
    game.run()