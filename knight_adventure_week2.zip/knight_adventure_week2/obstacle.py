import pygame
from config import *
class Obstacle(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.rect=pygame.Rect(*pos,tile_size,tile_size)
        self.hitbox=self.rect