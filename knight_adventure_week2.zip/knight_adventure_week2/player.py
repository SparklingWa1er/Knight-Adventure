import pygame
from config import *
from pygame import Vector2 as vector
from entity import *
from math import sin
from particles import *
from weapon import *
class Player(Entity):
    def __init__(self,pos,groups,obstacles,visible_instances,attack_instances):
        super().__init__(groups,"player",pos,obstacles,visible_instances)
        self.status="down"
        self.energy=self.stats["energy"]
        self.magic= list(magic_data.keys())[0]
        self.attack_instances=attack_instances
    def get_status(self):
        if self.direction==vector(0,0):
            if("_idle" not in self.status)and("_attack" not in self.status):
                self.status=self.status+"_idle"
        try:
            if self.attacking:
                self.direction=vector(0,0)
                if "_attack" not in self.status:
                    if("_idle" in self.status):
                        self.status=self.status[:-5:]
                    self.status+="_attack"
            else:
                if "_attack" in self.status:
                    self.status=self.status[:-7:]
        except:
            self.attacking=False
    def create_magic(self,style,strength,cost):
        if self.energy >= cost:
            if style == "heal":
                self.health = min(self.stats["health"], self.health + strength)
                Particle_effect(self.rect.center, "heal", [self.visible_instances])
            elif style == "flame":
                direction_in_text = self.status.split("_")[0]
                direction_dict = {"up": vector(0, -1), "down": vector(0, 1), "left": vector(-1, 0),"right": vector(1, 0)}
                direction = direction_dict[direction_in_text]
                off_set_dict = {"up": (-16, 16), "down": (0, -16), "left": (16, 16), "right": (-16, 16)}
                off_set = vector(off_set_dict[direction_in_text])
                Particle_effect((self.rect.centerx + direction.x * 4 * tile_size + off_set.x,self.rect.centery + direction.y * 4 * tile_size + off_set.y),"flame" + direction_in_text, [self.visible_instances, self.attack_instances])
            self.energy -= cost
    def input(self):
        try:
            if(self.can_switch_magic):pass
        except:
            self.can_switch_magic=True
        try:
            if(self.attacking):pass
        except:
            self.attacking=False
        try:
            if(self.magic_index):pass
        except:
            self.magic_index=0
        if(self.attacking):
            return
        keys=pygame.key.get_pressed()
        if(keys[pygame.K_UP]):
            self.status="up"
            self.direction.y=-1
        elif (keys[pygame.K_DOWN]):
            self.status="down"
            self.direction.y = 1
        else:
            self.direction.y=0
        if (keys[pygame.K_LEFT]):
            self.status="left"
            self.direction.x = -1
        elif (keys[pygame.K_RIGHT]):
            self.status="right"
            self.direction.x = 1
        else:
            self.direction.x=0
        #attack input
        if keys[pygame.K_a] and not self.attacking:
            self.attacking=True
            self.attack_time=pygame.time.get_ticks()
            self.current_attack=Weapon(self,[self.visible_instances,self.attack_instances])
        if keys[pygame.K_s] and not self.attacking:
            self.attack_time=pygame.time.get_ticks()
            self.attacking=True
            self.create_magic(self.magic,magic_data[self.magic]["strengh"]+self.stats["magic"],magic_data[self.magic]["cost"])
        if keys[pygame.K_q] and self.can_switch_magic:
            self.can_switch_magic=False
            self.magic_switch_time=pygame.time.get_ticks()
            self.magic_index=(self.magic_index+1)%len(list(magic_data.keys()))
            self.magic = list(magic_data.keys())[self.magic_index]
    def cooldown(self):
        current_time= pygame.time.get_ticks()
        try:
            if(self.vulnerable):pass
        except:
            self.vulnerable=True
        try:
            if(self.hurt_time):pass
        except:
            self.hurt_time=None
        try:
            if self.attack_time:pass
        except:
            self.attack_time=None
        try:
            if self.attacking:
                try:
                    if(current_time-self.attack_time>=self.stats["attack_cooldown"]):
                        self.attacking=False
                        if self.current_attack:
                            self.current_attack.kill()
                        self.current_attack = None
                except:
                    self.attack_time=None
            if not self.can_switch_magic:
                if(pygame.time.get_ticks()-self.magic_switch_time>=self.stats["switch_magic_cooldown"]):
                    self.can_switch_magic=True
            if not self.vulnerable:
                if current_time - self.hurt_time >=self.stats["invulnerable_duration"]:
                    self.vulnerable=True
        except:
            self.attacking=False
    def check_dead(self):
        if self.health<=0:
            self.stats["attack_cooldown"]=20000
            self.stats["speed"]=0
            self.image=self.animations["dead"][0]
            self.energy=0
            return True
        else:
            return False
    def update(self,_):
        self.input()
        self.cooldown()
        self.get_status()
        self.animate()
        self.move(self.stats["speed"])
        self.energy=min(self.energy+self.stats["magic"]/FPS,self.stats["energy"])