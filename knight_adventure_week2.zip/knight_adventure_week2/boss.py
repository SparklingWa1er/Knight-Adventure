from entity import *
from config import *
class Boss(Entity):
    def __init__(self,pos,groups,obstacles,type,visible_instances):
        super().__init__(groups,type,pos,obstacles,visible_instances)
        self.status="idle"
    def animate(self):
        try:
            if(self.frame_index):pass
        except:
            self.frame_index=0
        animation=self.animations[self.status]
        self.frame_index+=self.animation_speed
        self.frame_index%=len(animation)
        self.image=animation[int(self.frame_index)]
        self.rect=self.image.get_rect(center=self.hitbox.center)
    def get_status(self,player):
        try:
            if(self.vulnerable):pass
        except:
            self.vulnerable=True
        try:
            if(self.can_attack):pass
        except:
            self.can_attack=True
        if self.vulnerable and self.can_attack:
            direction=vector(player.hitbox.center)-vector(self.hitbox.center)
            distance=direction.magnitude()
            if(distance>0):
                direction=direction.normalize()
            else:
                direction=vector(0,0)
            if(distance<=self.stats["attack_radius"]):
                if self.status!="attack":
                    self.frame_index=0
                self.status="attack_left" if direction.x<0 else "attack_right"
            elif(distance<=self.stats["notice_radius"]):
                self.status="move"
            else:
                self.status="idle"
            if("attack" in self.status)and(self.can_attack):
                self.attack_time=pygame.time.get_ticks()
                self.can_attack=False
                self.direction=vector(0,0)
            elif(self.status=="move"):
                self.direction=direction
            else:
                self.direction=vector(0,0)
    def get_damage(self,player,attack_type):
        try:
            if(self.vulnerable):pass
        except:
            self.vulnerable=True
        if(self.vulnerable):
            if self.status in ["move","idle"]:
                self.status="hit"
            self.frame_index=0
            self.direction=vector(0,0)
            if(attack_type=="weapon"):
                self.health-=player.stats["attack"]
            elif("flame"in attack_type):
                self.health-=player.stats["magic"]*magic_data["flame"]["strengh"]
            self.hit_time=pygame.time.get_ticks()
            self.vulnerable=False
            return True
        return False
    def cooldown(self,player):
        try:
            if(self.can_attack):pass
        except:
            self.can_attack=True
        try:
            if(self.vulnerable):pass
        except:
            self.vulnerable=True
        current_time = pygame.time.get_ticks()
        if self.status=="dead":
            if current_time-self.dead_time>=1000:
                self.kill()
        else:
            if not self.can_attack:
                direction = vector(player.hitbox.center) - vector(self.hitbox.center)
                distance = direction.magnitude()
                if self.stats["damage_frames"]["start"]<=self.frame_index<self.stats["damage_frames"]["end"] and distance<=self.stats["attack_radius"] and player.vulnerable:
                    player.health -= self.stats["attack"]
                    player.vulnerable = False
                    player.hurt_time = pygame.time.get_ticks()
                    Particle_effect(player.rect.center, entity_data[self.type]["attack_type"],[self.visible_instances])
                if(current_time-self.attack_time>=self.stats["attack_cooldown"]):
                    self.can_attack=True
            if not self.vulnerable:
                if(pygame.time.get_ticks()-self.hit_time>=self.stats["hit_cooldown"]):
                    self.vulnerable=True
                    self.status="move"
    def check_dead(self):
        if(self.health<=0)and(self.status!="dead"):
            self.status="dead"
            self.dead_time=pygame.time.get_ticks()