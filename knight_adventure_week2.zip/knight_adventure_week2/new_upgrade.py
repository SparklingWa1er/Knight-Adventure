from config import *
import random
class Upgrade:
    def __init__(self,player):
        self.display_surface=pygame.display.get_surface()
        self.player=player
        first_stat_choices=[{"context":"Increase player's health by 100%   ({}|->{})".format(player.stats["health"],player.stats["health"]*2),"func":self.increase_health},{"context":"Increase player's energy by 100%   ({}|->{})".format(self.player.stats["energy"],self.player.stats["energy"]*2),"func":self.increase_energy}]
        second_stat_choices=[{"context":"Increase player's attack by 100%   ({}|->{})".format(self.player.stats["attack"],self.player.stats["attack"]*2),"func":self.increase_attack},{"context":"Increase player's magic by 100%   ({}|->{})".format(self.player.stats["magic"],self.player.stats["magic"]*2),"func":self.increase_magic},{"context":"Increase player's speed by 100%   {}|->{}".format(self.player.stats["speed"],self.player.stats["speed"]*2),"func":self.increase_speed}]
        third_stat_choices=[{"context":"Fully recover player's health","func":self.recover_health},{"context":"Fully recover player's energy","func":self.recover_energy}]
        self.upgrades=[random.choice(i) for i in[first_stat_choices,second_stat_choices,third_stat_choices]]
        self.font=pygame.font.Font(ui_font,ui_font_size)
        self.height=self.display_surface.get_height()*0.1
        self.width=self.display_surface.get_width()*0.6
        self.create_items()
        self.selection_index=1
        self.chosen=False
    def display(self):
        big_font=pygame.font.Font(ui_font,ui_font_size*2)
        text_surface = big_font.render("Enemy wave cleared, chose an upgrade for the player", False, text_color_selected)
        surface_size = self.display_surface.get_size()
        text_rect = text_surface.get_rect(center=(surface_size[0] // 2, surface_size[1] // 6))
        self.display_surface.blit(text_surface, text_rect)
        self.input()
        self.cooldown()
        for i,value in enumerate(self.item_list,0):
            value.display(self.display_surface,self.selection_index)
        if self.chosen: return True
    def input(self):
        try:
            if self.can_move:pass
        except:
            self.can_move=True
        if self.can_move:
            keys = pygame.key.get_pressed()
            if keys[pygame.K_DOWN]:
                self.selection_index+=1
                self.selection_time = pygame.time.get_ticks()
                self.can_move = False
            elif keys[pygame.K_UP]:
                self.selection_index-=1
                self.selection_time = pygame.time.get_ticks()
                self.can_move = False
            self.selection_index%=4
            self.selection_index=max(1,self.selection_index)
            if keys[pygame.K_SPACE]:
                self.item_list[self.selection_index-1].upgrade["func"]()
                self.chosen=True
    def cooldown(self):
        if not self.can_move:
            current_time=pygame.time.get_ticks()
            self.can_move=((current_time-self.selection_time)>=300)
    def increase_health(self):self.player.stats["health"]*=2
    def increase_energy(self): self.player.stats["energy"] *= 2
    def increase_attack(self): self.player.stats["attack"] *= 2
    def increase_magic(self): self.player.stats["magic"] *= 2
    def increase_speed(self): self.player.stats["speed"] *= 2
    def recover_health(self): self.player.health =self.player.stats["health"]
    def recover_energy(self): self.player.energy =self.player.stats["energy"]
    def create_items(self):
        self.item_list=[]
        top=self.display_surface.get_height()//3
        left=(self.display_surface.get_width()-self.width)//2
        for i in range(0,3):
            item=Item(left,top,self.width,self.height,self.font,i+1,self.upgrades[i])
            top+=self.height*2
            self.item_list.append(item)
class Item:
    def __init__(self,left,top,width,height,font,index,upgrade):
        self.rect=pygame.Rect(left,top,width,height)
        self.index=index
        self.font=font
        self.upgrade=upgrade
    def display_context(self,surface,selected):
        color=text_color if not selected else text_color_selected
        context_surf=self.font.render(self.upgrade["context"],False,color)
        context_rect=context_surf.get_rect(midtop=self.rect.midtop+vector(0,20))
        surface.blit(context_surf,context_rect)
    def display(self,surface,selection_index):
        selected=self.index==selection_index
        pygame.draw.rect(surface,ui_bg_color if not selected else upgrade_color_selected,self.rect)
        pygame.draw.rect(surface,ui_border_color,self.rect,4)
        self.display_context(surface,selected)