import pygame
from config import *
from obstacle import *
from player import *
from doccsv import *
from weapon import *
from ui import *
from enemy import Enemy
from particles import *
from new_upgrade import *
from enemy_wave import *
from boss import *
class Level:
    def __init__(self):
        self.index=1
        self.visible_instances=YSortCameraGroup(self.index)
        self.obstacle_instances=pygame.sprite.Group()
        self.display_surface=pygame.display.get_surface()
        self.attack_instances=pygame.sprite.Group()
        self.attackable_instances=pygame.sprite.Group()
        self.player=None
        self.enemy_wave_information=enemy_wave_info[self.index].copy()
        self.current_enemy_wave=Enemy_wave(self.enemy_wave_information[0]["list"],self.enemy_wave_information[0]["domain"],[self.attackable_instances,self.obstacle_instances,self.visible_instances],self.obstacle_instances,self.visible_instances)
        self.create()
        self.ui=UI()
        self.upgrade=Upgrade(self.player)
    def create(self):
        self.player = Player(initial_position[self.index], [self.visible_instances,self.obstacle_instances], self.obstacle_instances,self.visible_instances,self.attack_instances)
        for boss in boss_info[self.index]:
            Boss(boss["pos"],[self.visible_instances,self.obstacle_instances,self.attackable_instances],self.obstacle_instances,boss["type"],self.visible_instances)
        self.border=doccsv("map/map{}_border.csv".format(self.index))
        for line_index,line in enumerate(self.border,0):
            for index,value in enumerate(line,0):
                x=index*tile_size
                y=line_index*tile_size
                if (value != "-1"):Obstacle((x,y),[self.obstacle_instances])
    def run(self):
        try:
            if(self.game_paused):pass
        except:
            self.game_paused=False
        self.visible_instances.draw(self.player)
        self.current_enemy_wave.spawn(self.player)
        if self.game_paused:
            if self.upgrade.display():
                self.game_paused=False
                self.upgrade=Upgrade(self.player)
        else:
            self.ui.display(self.player)
            self.visible_instances.update(self.player)
            self.player_attack()
            self.check_end()
    def player_attack(self):
        if self.attack_instances:
            for attack_instance in self.attack_instances:
                collision_instances=pygame.sprite.spritecollide(attack_instance,self.attackable_instances,False)
                if collision_instances:
                    for collision_instance in collision_instances:
                        if(collision_instance.get_damage(self.player,attack_instance.type)):
                            Particle_effect(collision_instance.rect.center,"x_slash",[self.visible_instances])
    def check_end(self):
        self.font=pygame.font.Font(ui_font,ui_font_size*10)
        if(self.player.check_dead()):
            try:
                if (-self.dead_time+pygame.time.get_ticks()>=2000):
                    text_surface = self.font.render("Game over", False, text_color)
                    surface_size = self.display_surface.get_size()
                    text_rect = text_surface.get_rect(center=(surface_size[0]//2,surface_size[1]//2))
                    self.display_surface.fill(ui_bg_color)
                    self.display_surface.blit(text_surface, text_rect)
            except:
                self.dead_time=pygame.time.get_ticks()
        if self.current_enemy_wave.is_empty():
            try:
                self.enemy_wave_information.pop(0)
                self.current_enemy_wave = Enemy_wave(self.enemy_wave_information[0]["list"], self.enemy_wave_information[0]["domain"],[self.attackable_instances, self.obstacle_instances,self.visible_instances], self.obstacle_instances,self.visible_instances)
                self.game_paused = True
            except:
                if len(self.attackable_instances)==0:
                    try:
                        if (-self.clear_time + pygame.time.get_ticks() >= 2000):
                            text_surface = self.font.render("Vip", False, text_color)
                            surface_size = self.display_surface.get_size()
                            text_rect = text_surface.get_rect(center=(surface_size[0] // 2, surface_size[1] // 2))
                            self.display_surface.fill(ui_bg_color)
                            self.display_surface.blit(text_surface, text_rect)
                    except:
                        self.clear_time = pygame.time.get_ticks()

class YSortCameraGroup(pygame.sprite.Group):
    def __init__(self,index):
        super().__init__()
        self.display_surface=pygame.display.get_surface()
        self.offset=vector()
        self.ground_image=map_backgrounds[index].convert()
        self.ground_rect=self.ground_image.get_rect(topleft=(0,0))
    def draw(self,player):
        """giup nguoi choi luon o tam man hinh"""
        self.offset.x=player.rect.centerx-self.display_surface.get_size()[0]//2
        self.offset.y = player.rect.centery - self.display_surface.get_size()[1] // 2
        self.display_surface.blit(self.ground_image,vector(self.ground_rect.topleft)-self.offset)
        for sprite in sorted(self.sprites(),key=lambda x:x.rect.centery):
            if("enemy/" in sprite.type):
                bg_rect = pygame.Rect(sprite.rect.x-self.offset.x,sprite.rect.y-20-self.offset.y, 64, 15)
                pygame.draw.rect(self.display_surface, ui_bg_color, bg_rect)
                ratio = sprite.health / sprite.stats["health"]
                pygame.draw.rect(self.display_surface, health_color,pygame.Rect(bg_rect.x, bg_rect.y, bg_rect.width * ratio, bg_rect.height))
                pygame.draw.rect(self.display_surface, ui_border_color, bg_rect, 3)
            elif "boss/"in sprite.type:
                bg_rect = pygame.Rect(sprite.rect.centerx-self.offset.x-65,sprite.rect.centery-86-self.offset.y, 128, 20)
                pygame.draw.rect(self.display_surface, ui_bg_color, bg_rect)
                ratio = sprite.health / sprite.stats["health"]
                pygame.draw.rect(self.display_surface, health_color,pygame.Rect(bg_rect.x, bg_rect.y, bg_rect.width * ratio, bg_rect.height))
                pygame.draw.rect(self.display_surface, ui_border_color, bg_rect, 3)
            self.display_surface.blit(sprite.image,vector(sprite.rect.topleft)-self.offset)