from config import *
import pygame
from entity import *
from math import sin
from particles import *
class Enemy(Entity):
    def __init__(self,pos,groups,obstacles,type,visible_instances):
        super().__init__(groups,type,pos,obstacles,visible_instances)
        self.status="idle"
    def get_damage(self,player,attack_type):
        try:
            if(self.vulnerable):pass
        except:
            self.vulnerable=True
        if(self.vulnerable):
            new_direction=vector(player.hitbox.center)-vector(self.hitbox.center)
            self.status="move"
            if new_direction.magnitude()>0:
                self.direction=new_direction.normalize()
            else:
                self.direction=vector(0,0)
            if(attack_type=="weapon"):
                self.health-=player.stats["attack"]
            elif("flame"in attack_type):
                self.health-=player.stats["magic"]*magic_data["flame"]["strengh"]
            self.hit_time=pygame.time.get_ticks()
            self.vulnerable=False
            self.direction*=(-self.stats["resistance"])
            return True
        return False