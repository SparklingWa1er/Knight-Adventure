from config import *
from enemy import *
import random
class Enemy_wave:
    def __init__(self,enemy_list,domain,groups,obstacles,visible_instances):
        self.enemy_list=enemy_list.split()
        self.domain=domain
        topleft_x=self.domain.topleft[0]
        topleft_y=self.domain.topleft[1]
        topright_x=self.domain.topright[0]
        self.enemy_pos=([(topleft_x+tile_size*i,topleft_y)for i in range(self.domain.width//tile_size-1,-1,-2)]+
                        [(topright_x-tile_size,topleft_y+tile_size*i)for i in range(0,self.domain.height//tile_size,2)]+
                        [(topleft_x+tile_size*i,topleft_y)for i in range(1,self.domain.width//tile_size,2)]+
                        [(topright_x-tile_size,topleft_y+tile_size*i)for i in range(1,self.domain.height//tile_size,2)])
        self.enemy_pos=self.enemy_pos[:len(self.enemy_list)]
        self.groups=groups
        self.obstacles=obstacles
        self.visible_instances=visible_instances
    def is_empty(self):
        try:
            return all([(len(i.groups())==0) for i in self.enemy_list])
        except:
            return False
    def spawn(self,player):
        try:
            if self.has_spawn:pass
        except:
            if self.domain.collidepoint(player.rect.center):
                self.enemy_list=[Enemy(pos,self.groups,self.obstacles,type,self.visible_instances) for (pos,type) in zip(self.enemy_pos,self.enemy_list)]
                self.has_spawn=True