import pygame
from config import *
from border import *
from player import *
from doccsv import *
from weapon import *
from ui import *
from enemy import Enemy
from particles import *
from new_upgrade import *
from enemy_wave import *
from boss import *
class Level:
    """Lớp có chức năng thực thi 1 màn chơi"""
    def __init__(self,index):
        """Khởi tạo một đối tượng với các đặc tính:
        + index(integer): Số thứ tự của màn chơi.
        + running(boolean): Mang giá trị True nếu màn chơi chưa kết thúc và ngược lại.
        + obstacles_instances(pygame.sprite.Group): Nhóm các đối tượng là chướng ngoại vật để kiểm tra va chạm.
        + attack_instances(pygame.sprite.Group): Nhóm các đối tượng có thể gây sát thương cho kẻ địch.
        + attackable_instances(pygame.sprite.Group): Nhóm các đối tượng phải nhận sát thương khi va chạm với các đối tượng thuộc attack_instances.
        + player(Player): nhân vật được người chơi điều khiền(nhân vật chính).
        + enemy_wave_information(list of dictionary): Danh sách các nhóm kẻ địch ở ải tương ứng với đặc tính index.
        + enemy_wave_index(integer): Số thứ tự của nhóm kẻ địch hiện tại.
        + current_enemy_wave(Enemy_wave): Nhóm kẻ địch hiện tại
        + ui(UI): Giao diện người dùng của ải này.
        + upgrade(Upgrade): Đối tượng nâng cấp xuất hiện sau khi hạ mỗi đợt kẻ địch.
        """
        self.index=index
        self.running=True
        self.visible_instances=YSortCameraGroup(self.index)
        self.obstacle_instances=pygame.sprite.Group()
        self.display_surface=pygame.display.get_surface()
        self.attack_instances=pygame.sprite.Group()
        self.attackable_instances=pygame.sprite.Group()
        self.player=None
        self.enemy_wave_information=enemy_wave_info[self.index]
        self.enemy_wave_index=0
        self.current_enemy_wave=Enemy_wave(self.enemy_wave_information[self.enemy_wave_index]["list"],self.enemy_wave_information[self.enemy_wave_index]["domain"],[self.attackable_instances,self.obstacle_instances,self.visible_instances])
        self.player = Player(initial_position[self.index], [self.visible_instances,self.obstacle_instances], self.obstacle_instances,self.visible_instances,self.attack_instances)
        for boss in boss_info[self.index]:
            Boss(boss["pos"],[self.visible_instances,self.obstacle_instances,self.attackable_instances],self.obstacle_instances,boss["type"],self.visible_instances)
        border=doccsv("map/map{}_border.csv".format(self.index))
        for line_index,line in enumerate(border,0):
            for index,value in enumerate(line,0):
                x=index*tile_size
                y=line_index*tile_size
                if (value != "-1"):Border((x,y),[self.obstacle_instances])
        self.ui=UI()
        self.upgrade=Upgrade(self.player)
    def run(self):
        """Hàm này có chức năng thực thi trò chơi bằng cách cập nhật, in ra màn hình các đối tượng có thể nhìn thấy, dừng trò chơi khi xuất hiện nâng cấp."""
        try:
            if(self.game_paused):pass
        except:
            self.game_paused=False
        self.visible_instances.draw(self.player)
        self.current_enemy_wave.spawn(self.player)
        if self.game_paused:
            if self.upgrade.display():
                self.game_paused=False
                self.upgrade=Upgrade(self.player)
        else:
            self.ui.display(self.player)
            self.visible_instances.update(self.player)
            self.player_attack()
            self.check_end()
    def player_attack(self):
        """Kiểm tra va chạm của kẻ địch với các đòn tấn công của nhân vật chính và giảm máu của chúng."""
        if self.attack_instances:
            for attack_instance in self.attack_instances:
                collision_instances=pygame.sprite.spritecollide(attack_instance,self.attackable_instances,False)
                if collision_instances:
                    for collision_instance in collision_instances:
                        if(collision_instance.get_damage(self.player,attack_instance.type)):
                            Particle_effect(collision_instance.rect.center,"x_slash",[self.visible_instances])
    def check_end(self):
        """Kiểm tra màn chơi đã kết thúc chưa, nếu có ứng với mỗi kết thúc(mọi kẻ địch bị tiêu diệt hoặc nhân vâật chính bị hạ gục) in ra màn hình thông báo tương ứng"""
        self.font=pygame.font.Font(ui_font,ui_font_size*10)
        self.font=pygame.font.Font(ui_font,ui_font_size*10)
        if(self.player.check_dead()):
            try:
                if (-self.dead_time+pygame.time.get_ticks()>=2000):
                    try:
                        if self.game_over_played:pass
                    except:
                        game_over=pygame.mixer.Sound("sound/GameOver.wav")
                        game_over.play()
                        self.game_over_played=True
                    text_surface = self.font.render("Game over", False, text_color)
                    surface_size = self.display_surface.get_size()
                    text_rect = text_surface.get_rect(center=(surface_size[0]//2,surface_size[1]//2))
                    self.display_surface.fill(ui_bg_color)
                    self.display_surface.blit(text_surface, text_rect)
                    small_font=pygame.font.Font(ui_font,ui_font_size*2)
                    small_text_surface=small_font.render("Press any key to continue", False, text_color).convert_alpha()
                    small_text_surface.set_alpha(255 if sin(pygame.time.get_ticks()/50)>0 else 0)
                    small_text_rect = small_text_surface.get_rect(center=(surface_size[0]//2,int(surface_size[1]*0.75)))
                    self.display_surface.blit(small_text_surface, small_text_rect)
                    self.running=False
            except:
                self.dead_time=pygame.time.get_ticks()
        if self.current_enemy_wave.is_empty():
            self.enemy_wave_index+=1
            if self.enemy_wave_index<len(self.enemy_wave_information):
                self.current_enemy_wave = Enemy_wave(self.enemy_wave_information[self.enemy_wave_index]["list"], self.enemy_wave_information[self.enemy_wave_index]["domain"],[self.attackable_instances, self.obstacle_instances,self.visible_instances])
                self.game_paused = True
            elif self.enemy_wave_index==len(self.enemy_wave_information):
                self.game_paused=True
            else:
                if len(self.attackable_instances)==0:
                    try:
                        if (-self.clear_time + pygame.time.get_ticks() >= 2000):
                            try:
                                if self.victory_played: pass
                            except:
                                victory = pygame.mixer.Sound("sound/Success3.wav")
                                victory.play()
                                self.victory_played = True
                            text_surface = self.font.render("Victory", False, text_color)
                            surface_size = self.display_surface.get_size()
                            text_rect = text_surface.get_rect(center=(surface_size[0] // 2, surface_size[1] // 2))
                            self.display_surface.fill(ui_bg_color)
                            self.display_surface.blit(text_surface, text_rect)
                            small_font = pygame.font.Font(ui_font, ui_font_size * 2)
                            small_text_surface = small_font.render("Press any key to continue", False,text_color).convert_alpha()
                            small_text_surface.set_alpha(255 if sin(pygame.time.get_ticks()/50) > 0 else 0)
                            small_text_rect = small_text_surface.get_rect(center=(surface_size[0] // 2, int(surface_size[1] * 0.75)))
                            self.display_surface.blit(small_text_surface, small_text_rect)
                            self.running=False
                    except:
                        self.clear_time = pygame.time.get_ticks()

class YSortCameraGroup(pygame.sprite.Group):
    def __init__(self,index):
        super().__init__()
        self.display_surface=pygame.display.get_surface()
        self.offset=vector()
        self.ground_image=map_backgrounds[index].convert()
        self.ground_rect=self.ground_image.get_rect(topleft=(0,0))
    def draw(self,player):
        """giup nguoi choi luon o tam man hinh"""
        self.offset.x=player.rect.centerx-self.display_surface.get_size()[0]//2
        self.offset.y = player.rect.centery - self.display_surface.get_size()[1] // 2
        self.display_surface.blit(self.ground_image,vector(self.ground_rect.topleft)-self.offset)
        for sprite in sorted(self.sprites(),key=lambda x:x.rect.centery):
            if("enemy/" in sprite.type):
                bg_rect = pygame.Rect(sprite.rect.x-self.offset.x,sprite.rect.y-20-self.offset.y, 64, 15)
                pygame.draw.rect(self.display_surface, ui_bg_color, bg_rect)
                ratio = sprite.health / sprite.stats["health"]
                pygame.draw.rect(self.display_surface, health_color,pygame.Rect(bg_rect.x, bg_rect.y, bg_rect.width * ratio, bg_rect.height))
                pygame.draw.rect(self.display_surface, ui_border_color, bg_rect, 3)
            elif "boss/"in sprite.type:
                bg_rect = pygame.Rect(sprite.rect.centerx-self.offset.x-65,sprite.rect.centery-86-self.offset.y, 128, 20)
                pygame.draw.rect(self.display_surface, ui_bg_color, bg_rect)
                ratio = sprite.health / sprite.stats["health"]
                pygame.draw.rect(self.display_surface, health_color,pygame.Rect(bg_rect.x, bg_rect.y, bg_rect.width * ratio, bg_rect.height))
                pygame.draw.rect(self.display_surface, ui_border_color, bg_rect, 3)
            self.display_surface.blit(sprite.image,vector(sprite.rect.topleft)-self.offset)
