import pygame
from pygame import Vector2 as vector
from config import *
class UI:
    """Là lớp thể hiện hình ảnh thanh máu, thanh năng lượng và kỹ năng của nhân vật chính."""
    def __init__(self):
        """Khởi tạo một đối tượng có các đặc tính:
        + display_surface(pygame.surface.Surface): Màn hình trình chiếu trò chơi.
        + health_bar_rect(pygame.rect.Rect): Vùng in thanh máu trên màn hình.
        + energy_bar_rect(pygame.rect.Rect): Vùng in thanh năng lượng trên màn hình.
        + magic_graphics(dictionary): Tên kỹ năng và hình ảnh đại diện tương ứng của chúng."""
        self.display_surface=pygame.display.get_surface()
        self.health_bar_rect=pygame.Rect(10,10,health_bar_width,bar_height)
        self.energy_bar_rect=pygame.Rect(10,16+bar_height,energy_bar_width,bar_height)
        self.magic_graphics={"flame":pygame.transform.scale(pygame.image.load("image/animation_frames/flame/icon.png"),(tile_size,tile_size)),
                             "heal":pygame.transform.scale(pygame.image.load("image/animation_frames/heal/icon.png"),(tile_size,tile_size))}
    def show_bar(self,current_stat,max_stat,bg_rect,color):
        """Hàm nhận 4 tham số current_stat, max_stat thuộc kiểu integer là chỉ số máu hoặc năng lượng hiện tại và tối đa của nhân vật chính,
        bg_rect(pygame.rect.Rect) là vùng in thanh chỉ số với màu tương ứng là color(string) để có thể in thanh máu hoặc năng lượng
        hiện tại của nhân vật chính."""
        pygame.draw.rect(self.display_surface,ui_bg_color,bg_rect)
        ratio=current_stat/max_stat
        pygame.draw.rect(self.display_surface,color,pygame.Rect(bg_rect.x,bg_rect.y,bg_rect.width*ratio,bg_rect.height))
        pygame.draw.rect(self.display_surface,ui_border_color,bg_rect,3)
    def magic_overlay(self,player_magic,has_switched):
        """Hàm nhần vào 2 tham số player_magic (string) là kỹ năng hiện tại của nhân vật chính và giá trị boolean has_switched
        để vẽ ô kỹ năng của nhân vật chính ở trạng thái tương ứng."""
        bg_rect = pygame.Rect(10,630,item_box_size,item_box_size)
        pygame.draw.rect(self.display_surface,ui_bg_color,bg_rect)
        if has_switched:
            pygame.draw.rect(self.display_surface,ui_border_color_active,bg_rect,3)
        else:
            pygame.draw.rect(self.display_surface,ui_border_color,bg_rect,3)
        magic_surface=self.magic_graphics[player_magic]
        magic_rect=magic_surface.get_rect(center=bg_rect.center)
        self.display_surface.blit(magic_surface,magic_rect)
    def display(self,player):
        """Hàm này nhận vào tham số player kiểu Player để vẽ thanh máu, năng lượng và ô kỹ năng của người chơi lên màn hình."""
        try:
            if(player.can_switch_magic):pass
        except:
            player.can_switch_magic=True
        self.show_bar(player.health,player.stats["health"],self.health_bar_rect,health_color)
        self.show_bar(player.energy,player.stats["energy"],self.energy_bar_rect,energy_color)
        self.magic_overlay(player.magic,not player.can_switch_magic)
