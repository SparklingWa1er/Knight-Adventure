from config import *
import pygame
from pygame import Vector2 as vector
from particles import *
class Entity(pygame.sprite.Sprite):
    """Lớp được kế thừa từ built-in class pygame.sprite.Sprite của thư viện pygame thể hiện các đối tượng có thể
     di chuyển, tấn công và nhận sát thương trong trò chơi, các lớp Player, Enemy và Boss được thừa kế từ lớp này."""
    def __init__(self,groups,type,pos,obstacles,visible_instances):
        """Khởi tạo một đối tượng với các đặc tính:
        + groups(list of pygame.sprite.Group): Các nhóm đối tượng trong trò chơi chứa đối tượng được khởi tạo.
        + direction(pygame.Vector2): Thể hiện hướng di chuyển của đối tượng.
        + type(string): Tên đối tượng (có thể là player, enemy hoặc boss).
        + rect(pygame.rect.Rect): Vùng thể hiện vị trí của đối tượng trên bản đồ.
        + hitbox(pygame.rect.Rect): Vùng dùng để kiểm tra việc va chạm của đối tượng với các đối tượng khác.
        + obstacles(pygame.sprite.Group): Nhóm các chướng ngoại vật để kiểm tra va chạm.
        + visible_instances(pygame.sprite.Group): Nhóm các hiệu ứng đòn đánh, kỹ năng(được bổ sung mỗi khi đối tượng gây hoặc nhận sát thương).
        + stats(dictionary): Bộ chỉ số tối đa của đối tượng.
        + animation(dictionary): Bộ hình ảnh của đối tượng.
        + health(integer): Lượng máu hiện tại của đổi tượng.
        + status(string): Trạng thái hiện tại của đối tượng.
        """
        super().__init__(groups)
        self.direction=vector()
        self.animation_speed=0.15
        self.type=type
        self.image=pygame.transform.scale(pygame.image.load("image/{}/base_image.png".format(self.type)), (tile_size,tile_size))
        self.rect=self.image.get_rect(topleft=pos)
        self.hitbox=(self.image.get_rect(topleft=pos)).inflate(hitbox_offset[self.type])
        self.obstacles=obstacles
        self.visible_instances=visible_instances
        self.stats=entity_data[self.type].copy()
        self.animations=entity_animations[self.type]
        self.health=self.stats["health"]
        self.status="idle"
    def move(self,speed):
        """Hàm này nhận vào 1 tham số speed kiểu integer thể hiện tốc độ của đối tượng, từ đó thay đổi vị trí của đối
        tượng trên màn hình dựa theo speed và đặc tính direction."""
        if self.direction.magnitude()!=0:
            self.direction=self.direction.normalize()
        self.hitbox.x+=self.direction.x*speed
        self.collision("horizontal")
        self.hitbox.y+=self.direction.y*speed
        self.collision("vertical")
        self.rect.center=self.hitbox.center
    def collision(self,direction):
        """Hàm này nhận vào 1 tham số direction kiểu string là phương kiểm tra va chạm với các chướng ngoại vật
        thuộc attribute obstacles, nếu có xảy ra va chạm đặt lại vị trí của đối tượng về rìa của chướng ngoại vật."""
        if direction=="horizontal":
            for obstacle in self.obstacles:
                if (obstacle !=self) and obstacle.hitbox.colliderect(self.hitbox):
                    if(self.direction.x>0):
                        self.hitbox.right=obstacle.hitbox.left
                    if(self.direction.x<0):
                        self.hitbox.left=obstacle.hitbox.right
        if direction=="vertical":
            for obstacle in self.obstacles:
                if (obstacle !=self) and obstacle.hitbox.colliderect(self.hitbox):
                    if (self.direction.y > 0):
                        self.hitbox.bottom = obstacle.hitbox.top
                    if (self.direction.y < 0):
                        self.hitbox.top = obstacle.hitbox.bottom
    def animate(self):
        """Hàm này thực hiện việc lựa chọn hình ảnh dựa trên trạng thái của đối tượng, từ đó tạo hoạt ảnh chuển động cho nó."""
        try:
            if self.vulnerable:pass
        except:
            self.vulnerable=True
        try:
            if(self.frame_index):pass
        except:
            self.frame_index=0
        try:
            if self.spawn:pass
        except:
            frames_name=("enemy" if "enemy" in self.type else "player") + "_spawn"
            Particle_effect(self.rect.center,frames_name,[self.visible_instances])
            self.spawn=True
        animation=self.animations[self.status]
        self.frame_index+=self.animation_speed
        self.frame_index%=len(animation)
        self.image=animation[int(self.frame_index)]
        self.rect=self.image.get_rect(center=self.hitbox.center)
        if not self.vulnerable:
            self.image.set_alpha(255 if (sin(pygame.time.get_ticks())>0)else 0)
        else:
            self.image.set_alpha(255)
    def get_status(self,player):
        """Hàm này cập nhật trạng thái của đối tượng(có thể là attack, move,...) dựa trên vị trí và các hoạt động đối tượng vừa thực hiện."""
        try:
            if(self.vulnerable):pass
        except:
            self.vulnerable=True
        try:
            if(self.can_attack):pass
        except:
            self.can_attack=True
        if self.vulnerable:
            direction=vector(player.hitbox.center)-vector(self.hitbox.center)
            distance=direction.magnitude()
            if(distance>0):
                direction=direction.normalize()
            else:
                direction=vector(0,0)
            if(distance<=self.stats["attack_radius"]):
                if self.status!="attack":
                    self.frame_index=0
                self.status="attack"
            elif(distance<=self.stats["notice_radius"]):
                self.status="move"
            else:
                self.status="idle"
            if(self.status=="attack")and(self.can_attack):
                self.attack_time=pygame.time.get_ticks()
                if player.vulnerable:
                    sound=pygame.mixer.Sound("sound/Hit.wav")
                    sound.set_volume(0.2)
                    sound.play()
                    player.health-=self.stats["attack"]
                    player.vulnerable=False
                    player.hurt_time=pygame.time.get_ticks()
                    Particle_effect(player.rect.center, entity_data[self.type]["attack_type"], [self.visible_instances])
                self.can_attack=False
            elif(self.status=="move"):
                self.direction=direction
            else:
                self.direction=vector(0,0)
    def cooldown(self,_):
        """Hàm này giới hạn 2 khoảng thời gian giữa 2 thời điểm liên tiếp đối tượng có thể tấn công hay nhận sát thương."""
        try:
            if(self.can_attack):pass
        except:
            self.can_attack=True
        try:
            if(self.vulnerable):pass
        except:
            self.vulnerable=True
        current_time = pygame.time.get_ticks()
        if not self.can_attack:
            if(current_time-self.attack_time>=self.stats["attack_cooldown"]):
                self.can_attack=True
        if(not self.vulnerable):
            if(pygame.time.get_ticks()-self.hit_time>=self.stats["invulnerable_duration"]):
                self.vulnerable=True
    def check_dead(self):
        """Hàm này loại bỏ đối tượng khỏi trò chơi nếu nó không còn máu."""
        if(self.health<=0):
            self.kill()
    def update(self,player):
        """Hàm này là nơi thực thi các hàm ở trên, cập nhật trạng thái của đối tượng và vẽ chúng lên màn hình trò chơi."""
        self.move(self.stats["speed"])
        self.animate()
        self.cooldown(player)
        self.check_dead()
        self.get_status(player)