from config import *
from enemy import *
import random
class Enemy_wave:
    """Lớp này đại diện cho các đợt quái vật trong trò chơi, mỗi đối tượng thuộc lớp này chứa nhiều đối tượng thuộc lớp Enemy"""
    def __init__(self,enemy_list,domain,groups):
        """Khỏi tạo một đối tượng với các đặc tính:
        + enemy_list(list of string): Danh sách các kẻ địch có trong đối tượng.
        + domain(pygame.rect.Rect): Lãnh địa của đối tượng (các kẻ địch sẽ được tạo ra khi nhân vật nguời chơi điềukhiển bước vào vùng này).
        + enemy_pos(list of tuple): Danh sách vị trí của các kẻ địch trong đặc tính enemy_list khi được tạo ra.
        + groups(list of pygame.sprite.Group): Các nhóm đối tượng trong trò chơi chứa các kẻ địch của đối tượng được khởi tạo.
        """
        self.enemy_list=enemy_list.split()
        self.domain=domain
        topleft_x=self.domain.topleft[0]
        topleft_y=self.domain.topleft[1]
        topright_x=self.domain.topright[0]
        self.enemy_pos=([(topleft_x+tile_size*i,topleft_y)for i in range(self.domain.width//tile_size-1,-1,-3)]+
                        [(topright_x-tile_size,topleft_y+tile_size*i)for i in range(0,self.domain.height//tile_size,3)]+
                        [(topleft_x+tile_size*i,topleft_y)for i in range(1,self.domain.width//tile_size,3)]+
                        [(topright_x-tile_size,topleft_y+tile_size*i)for i in range(1,self.domain.height//tile_size,3)])
        self.enemy_pos=self.enemy_pos[:len(self.enemy_list)]
        self.groups=groups
    def is_empty(self):
        """Hàm này kiểm tra các kẻ địch của lớp này đã bị tiêu diệt hết chưa, nếu có hàm sẽ trả về True và ngược lại."""
        try:
            return all([(len(i.groups())==0) for i in self.enemy_list])
        except:
            return False
    def spawn(self,player):
        """Hàm này nhận vào tham số player kiểu Player để kiểm tra xem nhân vật chính đã bước vào lãnh địa của
        đối tượng chưa, nếu có thì các kẻ địch trong đối tượng này sẽ được tạo ra."""
        try:
            if self.has_spawn:pass
        except:
            if self.domain.collidepoint(player.rect.center):
                self.enemy_list=[Enemy(pos,self.groups,self.groups[1],type,self.groups[2]) for (pos,type) in zip(self.enemy_pos,self.enemy_list)]
                self.has_spawn=True
