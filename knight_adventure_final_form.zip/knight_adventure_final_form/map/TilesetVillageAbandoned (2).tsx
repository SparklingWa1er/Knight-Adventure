<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TilesetVillageAbandoned (2)" tilewidth="64" tileheight="64" tilecount="240" columns="20">
 <image source="../../../../Downloads/TilesetVillageAbandoned (2).png" width="1280" height="768"/>
</tileset>
