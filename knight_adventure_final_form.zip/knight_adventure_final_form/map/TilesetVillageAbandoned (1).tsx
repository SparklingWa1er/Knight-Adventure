<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TilesetVillageAbandoned (1)" tilewidth="128" tileheight="128" tilecount="240" columns="20">
 <image source="../../../../Downloads/TilesetVillageAbandoned (1).png" width="2560" height="1536"/>
</tileset>
