import pygame, sys
from config import *
from level import *
class Game:
    """Là lớp chứa các màn chơi và thực thi giao diện chọn màn chơi"""
    def __init__(self):
        """Khởi tạo 1 đối tượng với các đặc tính:
        + screen(pygame.surface.Surface): Cửa sổ trình chiếu trò chơi.
        + clock(pygame.time.Clock): Giới hạn FPS của trò chơi.
        + level(Level): Đối tượng màn chơi chuẩn bị được thực thi.
        """
        pygame.init()
        self.screen=pygame.display.set_mode((screen_width,screen_height))
        self.clock=pygame.time.Clock()
        self.level=None
        pygame.display.set_caption("Knight Adventure")
    def draw_menu(self,selected_option):
        """Hàm nhận vào tham số selected_option kiểu integer thể hiện lựa chọn của người chơi, từ đó in ra của sổ chọn ải với trạng thái tương ứng."""
        self.font=pygame.font.Font(ui_font,int(ui_font_size*2.5))
        self.screen.fill("Gray")
        menu_options=["Stage 1","Stage 2","Stage 3","Quit"]
        self.big_font=pygame.font.Font(ui_font,int(ui_font_size*4.5))
        for index,value in enumerate(["Knight","Adventure"],0):
            game_name=self.big_font.render(value,True,text_color_selected)
            rect = game_name.get_rect(center=(screen_width//2+25, screen_height//6 + index*100))
            self.screen.blit(game_name,rect)
        for idx, option in enumerate(menu_options):
            rect = pygame.Rect(screen_width//2-100, screen_height//2-50+100*idx, 250, 80)
            selected=idx==selected_option
            pygame.draw.rect(self.screen, ui_bg_color if not selected else upgrade_color_selected, rect)
            pygame.draw.rect(self.screen, ui_border_color, rect, 4)
            context_surf = self.font.render(option, False,text_color if not selected else text_color_selected)
            context_rect = context_surf.get_rect(midtop=rect.midtop)
            self.screen.blit(context_surf, context_rect)
        pygame.display.flip()
    def run(self):
        """Hàm in ra cửa sổ chọn ải và ứng với lựa chọn của người dùng tạo ra và thực thi màn chơi tương ứng hoặc thoát trò chơi."""
        menu_options=["Stage 1","Stage 2","Stage 3","Quit"]
        while(True):
            showing_menu=True
            selected_option=0
            while showing_menu:
                accept = pygame.mixer.Sound("sound/Accept.wav")
                change=pygame.mixer.Sound("sound/Menu1.wav")
                accept.set_volume(0.3)
                self.draw_menu(selected_option)
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        sys.exit()
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_UP:
                            selected_option = (selected_option - 1) % len(menu_options)
                            change.play()
                        elif event.key == pygame.K_DOWN:
                            selected_option = (selected_option + 1) % len(menu_options)
                            change.play()
                        elif event.key == pygame.K_RETURN:
                            accept.play()
                            if selected_option==len(menu_options)-1:
                                sys.exit()
                            showing_menu=False
            self.level=Level(selected_option+1)
            running=True
            while running:
                for event in pygame.event.get():
                    if event.type==pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                self.screen.fill((164, 212, 17))
                self.level.run()
                pygame.display.update()
                self.clock.tick(FPS)
                if not self.level.running:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                        elif event.type==pygame.KEYDOWN:
                            accept.play()
                            running=False
if  __name__=="__main__":
    game=Game()
    game.run()