from config import *
import pygame
from entity import *
from math import sin
from particles import *
class Enemy(Entity):
    """Là một lớp được kế thừa từ lớp Entity, đại diện các kẻ địch trong game"""
    def __init__(self,pos,groups,obstacles,type,visible_instances):
        """Khởi tạo một đối tượng mang các đặc tính được kế thừa từ lớp Entity."""
        super().__init__(groups,type,pos,obstacles,visible_instances)
    def get_damage(self,player,attack_type):
        """Hàm này nhận vào 2 tham số là player(Player) và attack_type(string) giảm máu đối tượng đi
        một lượng tương ứng khi đi vào vùng ảnh hưởng của các đòn tấn công của nhân vật chính."""
        try:
            if(self.vulnerable):pass
        except:
            self.vulnerable=True
        if(self.vulnerable):
            new_direction=vector(player.hitbox.center)-vector(self.hitbox.center)
            self.status="move"
            if new_direction.magnitude()>0:
                self.direction=new_direction.normalize()
            else:
                self.direction=vector(0,0)
            if(attack_type=="weapon"):
                self.health-=player.stats["attack"]
            elif("flame"in attack_type):
                self.health-=player.stats["magic"]*magic_data["flame"]["strengh"]
            self.hit_time=pygame.time.get_ticks()
            self.vulnerable=False
            self.direction*=(-self.stats["resistance"])
            return True
        return False
