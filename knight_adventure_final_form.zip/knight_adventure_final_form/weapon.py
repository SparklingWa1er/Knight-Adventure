from config import *
import pygame
from pygame import Vector2 as vector
class Weapon(pygame.sprite.Sprite):
    """Là một lớp được kế thừa từ lớp built_in pygame.sprite.Sprite của pygame với mỗi đối tượng
     thể hiện cho vũ khí của nhân vật chính."""
    def __init__(self,player,groups):
        """Khởi tạo một đối tượng với các đặc tính:
        + groups(list of pygame.sprite.Group): Các nhóm đối tượng trong trò chơi chứa đối tượng được khởi tạo.
        + rect(pygame.rect.Rect): Vùng thể hiện vị trí của đối tượng trên bản đồ và dùng để kiểm tra việc va chạm của đối tượng với các đối tượng khác.
        + image(pygame.surface.Surface): Hình ảnh của đối tượng. """
        super().__init__(groups)
        direction=player.status.split("_")[0]
        self.type="weapon"
        self.image=pygame.transform.scale(pygame.image.load("image/weapon/{}.png".format(direction)), (40,40)).convert_alpha()
        if(direction=="right"):
            self.rect=self.image.get_rect(midleft=(player.rect.midright+vector(0,16)))
        elif (direction == "left"):
            self.rect = self.image.get_rect(midright=(player.rect.midleft+vector(0,16)))
        elif (direction == "up"):
            self.rect = self.image.get_rect(midbottom=(player.rect.midtop-vector(16,0)))
        elif(direction == "down"):
            self.rect = self.image.get_rect(midtop=(player.rect.midbottom-vector(16,0)))
