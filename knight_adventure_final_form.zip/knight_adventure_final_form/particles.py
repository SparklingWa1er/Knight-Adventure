from config import *
import pygame
class Particle_effect(pygame.sprite.Sprite):
    """Là một lớp được kế thừa từ lớp built_in pygame.sprite.Sprite của pygame với mỗi đối tượng là 1 hiệu ứng đòn đánh, kỹ năng
    của 1 dối tượng thuộc 1 trong các lớp được kế thừa từ lớp Entity."""
    def __init__(self,pos,frames_name,groups):
        """Khởi tạo một đối tượng với các đặc tính:
        + groups(list of pygame.sprite.Group): Các nhóm đối tượng trong trò chơi chứa đối tượng được khởi tạo.
        + type(string): Tên bộ hình ảnh của đối tượng.
        + frame_index(float): số thứ tự của hình ảnh hiện tại trong bộ ảnh của đối tượng.
        + rect(pygame.rect.Rect): Vùng thể hiện vị trí của đối tượng trên bản đồ.
        + image(pygame.surface.Surface): Hình ảnh hiện tại của đối tượng.
        + animations(list of pygame.surface.Surface): Bộ hình ảnh của đối tượng."""
        super().__init__(groups)
        self.type=frames_name
        self.frame_index = 0
        self.animations = animation_frames[frames_name]
        self.image = self.animations[self.frame_index]
        self.rect = self.image.get_rect(center=pos)
    def update(self,_):
        """Hàm này tăng dần đặc tính frame_index của đối tượng, từ đó thay đổi ảnh ở đặc tính image tạo hoạt ảnh cho đối tượng."""
        self.frame_index += 0.15
        if self.frame_index >= len(self.animations):
            self.kill()
        else:
            self.image = self.animations[int(self.frame_index)]
help(Particle_effect)