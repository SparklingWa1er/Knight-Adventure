import pygame
from config import *
class Border(pygame.sprite.Sprite):
    """Là một lớp được kế thừa từ lớp built_in pygame.sprite.Sprite của pygame với mỗi đối tượng là 1 ô vuông biên giới
    vô hình nhằm ngăn cản nhân vật chính không đi ra khỏi bản đồ."""
    def __init__(self,pos,groups):
        """Khởi tạo một đối tượng với các đặc tính:
        + groups(list of pygame.sprite.Group): Các nhóm đối tượng trong trò chơi chứa đối tượng được khởi tạo.
        + rect(pygame.rect.Rect): Vùng thể hiện vị trí của đối tượng trên bản đồ.
        + hit_box(pygame.rect.Rect): Vùng dùng để kiểm tra việc va chạm của đối tượng với các đối tượng khác. """
        super().__init__(groups)
        self.rect=pygame.Rect(*pos,tile_size,tile_size)
        self.hitbox=self.rect
help(Border)